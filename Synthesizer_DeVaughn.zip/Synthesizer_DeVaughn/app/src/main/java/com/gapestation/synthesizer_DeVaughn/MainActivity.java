package com.gapestation.synthesizer_DeVaughn;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final String TAG = MainActivity.class.getName();
    private final int WHOLE_NOTE = 1000;
    private Button button1;
    private Button button2;
    private Button c1Button;
    private Button c2Button;
    private Button c3Button;
    private Button c5Button;
    private Button c7Button;
    private Button c9Button;
    private Button c8Button;
    private Button c1011Button;
    private Button c12Button;
    private CheckBox checkBox;
    private Spinner spinner;
    private Spinner spinner2;
    private Spinner spinner3;
    private MediaPlayerThread mpt;
    private MediaPlayer mpE;
    private MediaPlayer mpF;
    private MediaPlayer mpFs;
    private MediaPlayer mpGs;
    private MediaPlayer mpA;
    private MediaPlayer mpB;
    private MediaPlayer mpCs;
    private MediaPlayer mpDs;
    private MediaPlayer mpEh;
    private MediaPlayer mpFhs;
    private MediaPlayer mpD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        c1Button = (Button)findViewById(R.id.c1Button);
        c2Button = (Button)findViewById(R.id.c2Button);
        c3Button = (Button)findViewById(R.id.c3Button);
        c5Button = (Button)findViewById(R.id.c5Button);
        c7Button = (Button)findViewById(R.id.c7Button);
        c9Button = (Button)findViewById(R.id.c9Button);
        c8Button = (Button)findViewById(R.id.c8Button);
        c1011Button = (Button)findViewById(R.id.c1011Button);
        c12Button = (Button)findViewById(R.id.c12Button);
        checkBox = (CheckBox)findViewById(R.id.checkBox);
        spinner = (Spinner)findViewById(R.id.spinner);
        spinner2 = (Spinner)findViewById(R.id.spinner2);
        spinner3 = (Spinner)findViewById(R.id.spinner3);
        mpt = new MediaPlayerThread(MainActivity.this);
        mpE = MediaPlayer.create(this, R.raw.scalee);
        mpF = MediaPlayer.create(this, R.raw.scalef);
        mpFs = MediaPlayer.create(this, R.raw.scalefs);
        mpGs = MediaPlayer.create(this, R.raw.scalegs);
        mpA = MediaPlayer.create(this, R.raw.scalea);
        mpB = MediaPlayer.create(this, R.raw.scaleb);
        mpCs = MediaPlayer.create(this, R.raw.scalecs);
        mpDs = MediaPlayer.create(this, R.raw.scaleds);
        mpEh = MediaPlayer.create(this, R.raw.scalehighe);
        mpFhs = MediaPlayer.create(this, R.raw.scalehighfs);
        mpD = MediaPlayer.create(this, R.raw.scaled);
        final MediaPlayer [] Challenge3 = {mpE, mpFs, mpGs, mpA, mpB, mpCs, mpDs, mpE};
        final int[] C2 = {R.raw.scalea, R.raw.scaleb, R.raw.scalebb, R.raw.scalec, R.raw.scalecs, R.raw.scaled, R.raw.scaleds, R.raw.scalee, R.raw.scalef, R.raw.scalefs, R.raw.scaleg, R.raw.scalegs, R.raw.scalehighe, R.raw.scalehighf, R.raw.scalehighfs, R.raw.scalehighg};
        final int[] C7 = {R.raw.scalea, R.raw.scalea, R.raw.scalehighe, R.raw.scalehighe, R.raw.scalehighfs, R.raw.scalehighfs, R.raw.scalehighe, R.raw.scaled, R.raw.scaled, R.raw.scalecs, R.raw.scalecs, R.raw.scaleb, R.raw.scaleb, R.raw.scalea};
        final int[] C9 = {R.raw.scalehighe, R.raw.scalehighe, R.raw.scaled, R.raw.scaled, R.raw.scalecs, R.raw.scalecs, R.raw.scaleb};
        final int[] C12 = {R.raw.scalee, R.raw.scaled, R.raw.scalec, R.raw.scaled, R.raw.scalee, R.raw.scalee, R.raw.scalee, R.raw.scaled, R.raw.scaled, R.raw.scaled, R.raw.scalee, R.raw.scalee, R.raw.scalee, R.raw.scalee, R.raw.scaled, R.raw.scalec, R.raw.scaled, R.raw.scalee, R.raw.scalee, R.raw.scalee, R.raw.scalee, R.raw.scaled, R.raw.scaled, R.raw.scalee, R.raw.scaled, R.raw.scalec};
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.notes, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.times, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.times, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter3);
        spinner.setOnItemSelectedListener(this);
        spinner2.setOnItemSelectedListener(this);
        spinner3.setOnItemSelectedListener(this);

        button1.setOnClickListener(new View.OnClickListener() {
            private void delayPlaying(int delay) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("SynthesizerActivity","Audio playback interrupted");
                }
            }

            @Override
            public void onClick(View v) {
                Log.e(TAG, "Button 1 clicked");
                mpE.start();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            private void delayPlaying(int delay) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("SynthesizerActivity","Audio playback interrupted");
                }
            }

            @Override
            public void onClick(View v) {
                Log.e(TAG, "Button 2 clicked");
                mpF.start();
            }
        });

        c1Button.setOnClickListener(new View.OnClickListener() {
            private void delayPlaying(int delay) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("SynthesizerActivity","Audio playback interrupted");
                }
            }
            @Override
            public void onClick(View v) {
                Log.e (TAG, "c1 clicked");
                mpE.start();
                delayPlaying(WHOLE_NOTE/2);
                mpFs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpGs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpA.start();
                delayPlaying(WHOLE_NOTE/2);
                mpB.start();
                delayPlaying(WHOLE_NOTE/2);
                mpCs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpDs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpE.start();
            }
        });

        c2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c2 clicked");
                int i;
                for (i = spinner2.getSelectedItemPosition() + 1; i > 0; i--) {
                    mpt.playNote(C2[spinner.getSelectedItemPosition()], WHOLE_NOTE);
                }
            }
        });

        c3Button.setOnClickListener(new View.OnClickListener() {
            private void delayPlaying(int delay) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("SynthesizerActivity","Audio playback interrupted");
                }
            }
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c3 clicked");
              for(MediaPlayer x: Challenge3) {
                x.start();
                delayPlaying(WHOLE_NOTE/2);
              }
            }
        });

        c5Button.setOnClickListener(new View.OnClickListener() {
            private void delayPlaying(int delay) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("SynthesizerActivity","Audio playback interrupted");
                }
            }
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c5 clicked");
                mpA.start();
                delayPlaying(WHOLE_NOTE/2);
                mpA.start();
                delayPlaying(WHOLE_NOTE/2);
                mpEh.start();
                delayPlaying(WHOLE_NOTE/2);
                mpFhs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpFhs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpEh.start();
                delayPlaying(WHOLE_NOTE/2);
                mpD.start();
                delayPlaying(WHOLE_NOTE/2);
                mpD.start();
                delayPlaying(WHOLE_NOTE/2);
                mpCs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpCs.start();
                delayPlaying(WHOLE_NOTE/2);
                mpB.start();
                delayPlaying(WHOLE_NOTE/2);
                mpB.start();
                delayPlaying(WHOLE_NOTE/2);
                mpA.start();


            }
        });

        c7Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c7 clicked");
                int i;
                for(i=0; i < C7.length; i++){
                    mpt.playNote(C7[i], WHOLE_NOTE);
                }
            }
        });

        c8Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c8 clicked");
                int i;
                for(i=0; i < C7.length; i++){
                    mpt.playNote(C7[i], WHOLE_NOTE/2);
                }
            }
        });

        c9Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c9 clicked");
                int i;
                for(i=0; i < C7.length; i++){
                    mpt.playNote(C7[i], WHOLE_NOTE/2);
                }
                for(i = 0; i < C9.length; i++){
                    mpt.playNote(C9[i], WHOLE_NOTE/2);
                }
                for(i=0; i < C7.length; i++){
                    mpt.playNote(C7[i], WHOLE_NOTE/2);
                }
            }
        });

        c1011Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c1011 clicked");
                if (checkBox.isChecked()){
                    int i;
                    for(i=0; i < C7.length; i++){
                        mpt.playNote(C7[i], WHOLE_NOTE/2);
                    }
                    for(i = spinner3.getSelectedItemPosition() + 1; i > 0; i--) {
                        for (i = 0; i < C9.length; i++) {
                            mpt.playNote(C9[i], WHOLE_NOTE / 2);
                        }
                    }
                    for(i=0; i < C7.length; i++){
                        mpt.playNote(C7[i], WHOLE_NOTE/2);
                    }
                }
                else {
                    int i;
                    for(i=0; i < C7.length; i++){
                        mpt.playNote(C7[i], WHOLE_NOTE/2);
                    }
                    for(i=0; i < C7.length; i++){
                        mpt.playNote(C7[i], WHOLE_NOTE/2);
                    }
                }
            }
        });
            //Mary had a little lamb
        c12Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG, "c12 clicked");
                int i;
                for(i=0; i < C12.length; i++){
                    mpt.playNote(C12[i], WHOLE_NOTE/2);
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


}